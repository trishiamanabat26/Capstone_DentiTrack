<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

include '../config/db.php';  // Assumes this file creates $conn as mysqli connection

$admin_username = $_SESSION['username'];

// Count total patients from users table
$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'patient'");
$patients_count = $result ? $result->fetch_assoc()['count'] : 0;

// Count total secretaries
$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'secretary'");
$secretary_count = $result ? $result->fetch_assoc()['count'] : 0;

// Count total admins
$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
$admin_count = $result ? $result->fetch_assoc()['count'] : 0;

// Count total doctors (NEW)
$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'doctor'");
$doctor_count = $result ? $result->fetch_assoc()['count'] : 0;

// Count total upcoming appointments
$result = $conn->query("SELECT COUNT(*) as count FROM appointments WHERE appointment_date >= CURDATE()");
$upcoming_appointments = $result ? $result->fetch_assoc()['count'] : 0;

// Uncomment and adjust these if payments table exists
// $result = $conn->query("SELECT COUNT(*) as count FROM payments");
// $payments_count = $result ? $result->fetch_assoc()['count'] : 0;

// $result = $conn->query("SELECT IFNULL(SUM(amount), 0) as total FROM payments");
// $total_payments = $result ? $result->fetch_assoc()['total'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Admin Dashboard - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" />
<style>
    html { scroll-behavior: smooth; }
    body {
        margin: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #e6f0ff;
        color: #003366;
        height: 100vh;
        display: flex;
        overflow: hidden;
    }
    .sidebar {
        width: 220px;
        background: linear-gradient(to bottom, #3399ff, #0066cc);
        padding: 20px 0;
        color: white;
        box-shadow: 2px 0 10px rgba(0,0,0,0.15);
        display: flex;
        flex-direction: column;
        user-select: none;
    }
    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
        font-weight: 700;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }
    .sidebar a {
        display: block;
        padding: 14px 24px;
        margin: 10px 15px;
        color: #cce0ff;
        text-decoration: none;
        border-left: 4px solid transparent;
        font-weight: 600;
        font-size: 15px;
        border-radius: 4px;
        transition: background-color 0.3s ease, border-left-color 0.3s ease;
    }
    .sidebar a i {
    margin-right: 10px;
}

    .sidebar a:hover,
    .sidebar a.active {
        background-color: rgba(255,255,255,0.15);
        color: white;
        border-left: 4px solid #ffcc00;
    }
    main.main-content {
        flex: 1;
        padding: 40px 60px;
        background: white;
        overflow-y: auto;
        box-sizing: border-box;
    }
    header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }
    header h1 {
        font-size: 2rem;
        color: #004080;
        text-shadow: 1px 1px 2px #a3c2ff;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .welcome {
        font-size: 1.3rem;
        margin-bottom: 2rem;
        font-weight: 600;
    }
    .widgets {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 30px;
    }
    .widget {
        background: #f0f7ff;
        padding: 30px 25px;
        border-radius: 15px;
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        text-align: left;
        cursor: pointer;
        transition: transform 0.3s ease, background-color 0.3s ease;
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        user-select: none;
    }
    .widget:hover {
        transform: translateY(-5px);
        background-color: #d9e8ff;
    }
    .widget i {
        font-size: 40px;
        color: #004080;
        margin-bottom: 12px;
    }
    .widget .title {
        font-size: 18px;
        font-weight: 700;
        color: #003366;
    }
    .widget .value {
        font-size: 44px;
        font-weight: 900;
        color: #004080;
    }
    .widget .subtitle {
        font-size: 14px;
        color: #666;
        font-weight: 500;
    }
</style>
</head>
<body>
<nav class="sidebar">
    <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a>
    <a href="manage_accounts.php"><i class="fas fa-users-cog"></i> Manage Accounts</a>
    <a href="generate_reports.php"><i class="fas fa-chart-line"></i> Generate Reports</a>
    <a href="payment_module.php"><i class="fas fa-money-check-dollar"></i> Payment Module</a>
    <a href="appointments.php"><i class="fas fa-calendar-check"></i> Appointments</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main class="main-content">
    <header>
        <h1><i class="fas fa-user-shield"></i> Admin Dashboard</h1>
    </header>

    <p class="welcome">Welcome, <strong><?= htmlspecialchars($admin_username) ?></strong>!</p>

    <div class="widgets">
        <div class="widget" onclick="location.href='manage_accounts.php'">
            <i class="fas fa-users"></i>
            <div class="title">Total Patients</div>
            <div class="value"><?= $patients_count ?></div>
            <div class="subtitle">Registered patients</div>
        </div>

        <div class="widget" onclick="location.href='manage_accounts.php'">
            <i class="fas fa-user-tie"></i>
            <div class="title">Total Secretaries</div>
            <div class="value"><?= $secretary_count ?></div>
            <div class="subtitle">Active secretaries</div>
        </div>

        <div class="widget" onclick="location.href='manage_accounts.php'">
            <i class="fas fa-user-shield"></i>
            <div class="title">Total Admins</div>
            <div class="value"><?= $admin_count ?></div>
            <div class="subtitle">System administrators</div>
        </div>

        <div class="widget" onclick="location.href='manage_accounts.php'">
            <i class="fas fa-user-md"></i>
            <div class="title">Total Doctors</div>
            <div class="value"><?= $doctor_count ?></div>
            <div class="subtitle">Registered doctors</div>
        </div>

        <div class="widget" onclick="location.href='generate_reports.php'">
            <i class="fas fa-file-chart-column"></i>
            <div class="title">Upcoming Appointments</div>
            <div class="value"><?= $upcoming_appointments ?></div>
            <div class="subtitle">Scheduled appointments</div>
        </div>

        <!-- Payments widgets commented out because table might not exist -->
        <!--
        <div class="widget" onclick="location.href='payment_module.php'">
            <i class="fas fa-money-check-dollar"></i>
            <div class="title">Total Payments</div>
            <div class="value"><?= $payments_count ?></div>
            <div class="subtitle">Transactions recorded</div>
        </div>

        <div class="widget" onclick="location.href='payment_module.php'">
            <i class="fas fa-wallet"></i>
            <div class="title">Sum of Payments</div>
            <div class="value">₱<?= number_format($total_payments, 2) ?></div>
            <div class="subtitle">Collected revenue</div>
        </div>
        -->
    </div>
</main>
</body>
</html>
