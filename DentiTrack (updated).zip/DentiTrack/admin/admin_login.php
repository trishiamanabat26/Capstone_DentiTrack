<?php
session_start();
require_once '../config/dbpdo.php'; // your PDO connection file (defines $pdo)

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Admin Registration
    if (isset($_POST['register'])) {
        $username = trim($_POST['username']);
        $password = $_POST['password'];
        $confirm = $_POST['confirm_password'];

        if ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            // Check if username exists
            $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                $error = 'Username already exists.';
            } else {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash) VALUES (?, ?)");
                if ($stmt->execute([$username, $hashed])) {
                    $success = 'Registration successful. You can now log in.';
                } else {
                    $error = 'Failed to create admin account.';
                }
            }
        }
    }

    // Admin Login
    if (isset($_POST['login'])) {
        $username = trim($_POST['username']);
        $password = $_POST['password'];

        // Fetch admin user
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            $_SESSION['admin_id'] = $admin['admin_id'];
            $_SESSION['username'] = $admin['username'];
            $_SESSION['role'] = 'admin';

            header('Location: admin_dashboard.php');
            exit;
        } else {
            $error = 'Invalid login credentials.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Login & Registration</title>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    crossorigin="anonymous"
    referrerpolicy="no-referrer"
  />
  <style>
    /* Same styles as your secretary form */
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f5f8ff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
    }
    .auth-wrapper {
      width: 400px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 12px 24px rgba(0,0,0,0.15);
      padding: 30px 40px;
      box-sizing: border-box;
    }
    .auth-container {
      display: flex;
      flex-direction: column;
    }
    h2 {
      color: #007bff;
      margin-bottom: 25px;
      text-align: center;
    }
    .form-card {
      display: block;
    }
    .hidden {
      display: none;
    }
    .input-icon {
      position: relative;
      margin-bottom: 20px;
    }
    .input-icon input {
      padding-left: 40px;
      width: 100%;
      height: 38px;
      font-size: 16px;
      border: 1.5px solid #ccc;
      border-radius: 7px;
      transition: border-color 0.3s;
      box-sizing: border-box;
    }
    .input-icon input:focus {
      outline: none;
      border-color: #007bff;
    }
    .input-icon i {
      position: absolute;
      top: 50%;
      left: 12px;
      transform: translateY(-50%);
      color: #007bff;
      font-size: 18px;
      pointer-events: none;
    }
    button {
      background-color: #007bff;
      color: white;
      font-weight: 600;
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 7px;
      font-size: 17px;
      cursor: pointer;
      transition: background-color 0.3s;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    button i {
      margin-right: 8px;
      font-size: 18px;
    }
    button:hover {
      background-color: #0056b3;
    }
    p {
      text-align: center;
      font-size: 14px;
      margin-top: 15px;
    }
    p a {
      color: #007bff;
      text-decoration: none;
      cursor: pointer;
      font-weight: 600;
    }
    .error, .success {
      font-weight: 600;
      padding: 10px;
      border-radius: 7px;
      margin-bottom: 15px;
      text-align: center;
    }
    .error {
      background-color: #ffdddd;
      color: #cc0000;
    }
    .success {
      background-color: #ddffdd;
      color: #008800;
    }
    .back-button {
      margin-top: 20px;
      background-color: #eee;
      color: #444;
      border-radius: 7px;
      border: 1px solid #ccc;
      cursor: pointer;
      width: 100%;
      padding: 10px;
      font-size: 15px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .back-button i {
      margin-right: 8px;
    }
    .back-button:hover {
      background-color: #ddd;
    }
  </style>
</head>
<body>

<div class="auth-wrapper">
  <div class="auth-container">

    <!-- Login Form -->
    <div class="form-card" id="login-form" <?= (isset($_POST['register']) ? 'class="hidden"' : '') ?>>
      <h2><i class="fas fa-user-shield"></i> Admin Login</h2>
      <?php if ($error && isset($_POST['login'])): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <?php if ($success && isset($_POST['login'])): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
      <?php endif; ?>
      <form method="POST" autocomplete="off">
        <div class="input-icon">
          <i class="fas fa-user"></i>
          <input type="text" name="username" placeholder="Username" required />
        </div>
        <div class="input-icon">
          <i class="fas fa-lock"></i>
          <input type="password" name="password" placeholder="Password" required />
        </div>
        <button type="submit" name="login"><i class="fas fa-right-to-bracket"></i> Login</button>
      </form>
      <p>Don't have an account? <a onclick="toggleForm('register')">Register</a></p>
    </div>

    <!-- Register Form -->
    <div class="form-card hidden" id="register-form" <?= (isset($_POST['register']) ? '' : 'class="hidden"') ?>>
      <h2><i class="fas fa-user-plus"></i> Admin Registration</h2>
      <?php if ($error && isset($_POST['register'])): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <?php if ($success && isset($_POST['register'])): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
      <?php endif; ?>
      <form method="POST" autocomplete="off">
        <div class="input-icon">
          <i class="fas fa-user"></i>
          <input type="text" name="username" placeholder="Username" required />
        </div>
        <div class="input-icon">
          <i class="fas fa-lock"></i>
          <input type="password" name="password" placeholder="Password" required />
        </div>
        <div class="input-icon">
          <i class="fas fa-lock"></i>
          <input type="password" name="confirm_password" placeholder="Confirm Password" required />
        </div>
        <button type="submit" name="register"><i class="fas fa-user-check"></i> Register</button>
      </form>
      <p>Already have an account? <a onclick="toggleForm('login')">Login here</a></p>
    </div>

  </div>
  <button class="back-button" onclick="window.history.back()"><i class="fas fa-arrow-left"></i> Back</button>
</div>

<script>
  function toggleForm(formType) {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');

    if (formType === 'register') {
      loginForm.classList.add('hidden');
      registerForm.classList.remove('hidden');
    } else {
      registerForm.classList.add('hidden');
      loginForm.classList.remove('hidden');
    }
  }
</script>

</body>
</html>
