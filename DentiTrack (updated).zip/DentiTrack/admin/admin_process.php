<?php
session_start();
require_once '../config/db_pdo.php'; // This defines $pdo (PDO instance)

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Invalid request method.";
    header("Location: admin_login.php");
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';
$action = isset($_POST['login']) ? 'login' : (isset($_POST['register']) ? 'register' : '');

if ($action === 'login') {
    if (empty($username) || empty($password)) {
        $_SESSION['error'] = "Please enter username and password.";
        header("Location: admin_login.php");
        exit;
    }

    // Fetch admin by username
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin || !password_verify($password, $admin['password_hash'])) {
        $_SESSION['error'] = "Invalid username or password.";
        header("Location: admin_login.php");
        exit;
    }

    // Login successful - set session variables including role
    $_SESSION['admin_id'] = $admin['admin_id'];
    $_SESSION['username'] = $admin['username'];
    $_SESSION['role'] = 'admin';  // Important for dashboard access!

    header("Location: admin_dashboard.php");
    exit;
}

if ($action === 'register') {
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (!$username || !$password || !$confirm_password) {
        $_SESSION['error'] = "Please fill in all fields.";
        header("Location: admin_login.php");
        exit;
    }

    if ($password !== $confirm_password) {
        $_SESSION['error'] = "Passwords do not match.";
        header("Location: admin_login.php");
        exit;
    }

    // Check if username exists
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch(PDO::FETCH_ASSOC)) {
        $_SESSION['error'] = "Username already exists.";
        header("Location: admin_login.php");
        exit;
    }

    // Create new admin
    $password_hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash) VALUES (?, ?)");
    $stmt->execute([$username, $password_hash]);

    $_SESSION['success'] = "Registration successful. You can now log in.";
    header("Location: admin_login.php");
    exit;
}

// If no valid action:
$_SESSION['error'] = "Invalid action.";
header("Location: admin_login.php");
exit;
