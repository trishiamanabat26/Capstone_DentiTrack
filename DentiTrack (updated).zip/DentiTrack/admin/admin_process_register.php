<?php
session_start();
require_once '../config/db_pdo.php';  // uses $conn

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Invalid request method.";
    header("Location: admin_register.php");
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';
$fullname = trim($_POST['fullname'] ?? '');
$email = trim($_POST['email'] ?? '');
$contact_number = trim($_POST['contact_number'] ?? '');

if (!$username || !$password || !$confirm_password || !$fullname || !$email || !$contact_number) {
    $_SESSION['error'] = "Please fill in all required fields.";
    header("Location: admin_register.php");
    exit;
}

if ($password !== $confirm_password) {
    $_SESSION['error'] = "Passwords do not match.";
    header("Location: admin_register.php");
    exit;
}

// Check if username exists
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
if ($stmt->fetch()) {
    $_SESSION['error'] = "Username already exists.";
    header("Location: admin_register.php");
    exit;
}

$password_hash = password_hash($password, PASSWORD_BCRYPT);

try {
    $conn->beginTransaction();

    $stmt = $conn->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'admin')");
    $stmt->execute([$username, $password_hash]);
    $user_id = $conn->lastInsertId();

    $stmt2 = $conn->prepare("INSERT INTO admins (user_id, full_name, email, contact_number) VALUES (?, ?, ?, ?)");
    $stmt2->execute([$user_id, $fullname, $email, $contact_number]);

    $conn->commit();

    $_SESSION['success'] = "Registration successful. You can now log in.";
    header("Location: admin_login.php");
    exit;

} catch (Exception $e) {
    $conn->rollBack();
    $_SESSION['error'] = "Registration failed: " . $e->getMessage();
    header("Location: admin_register.php");
    exit;
}
