<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit();
}
include '../config/db.php';

if (!isset($_GET['user_id'])) {
    echo "No user ID.";
    exit();
}
$user_id = intval($_GET['user_id']);
$stmt = $conn->prepare("SELECT username, role FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
if (!$user) {
    echo "User not found.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Account</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #eef3ff;
            padding: 40px;
            color: #003366;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 400px;
            margin: auto;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }
        label {
            display: block;
            margin-top: 15px;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        button {
            margin-top: 20px;
            padding: 10px 18px;
            background: #3399ff;
            border: none;
            color: white;
            border-radius: 6px;
            cursor: pointer;
        }
        a {
            display: inline-block;
            margin-top: 15px;
            color: #666;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Edit Account</h2>
    <form method="POST" action="save_account.php">
        <input type="hidden" name="user_id" value="<?= $user_id ?>">
        <label>Username:</label>
        <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
        <label>Password (leave blank to keep current):</label>
        <input type="password" name="password">
        <label>Role:</label>
        <select name="role" required>
            <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
            <option value="secretary" <?= $user['role'] == 'secretary' ? 'selected' : '' ?>>Secretary</option>
            <option value="patient" <?= $user['role'] == 'patient' ? 'selected' : '' ?>>Patient</option>
        </select>
        <button type="submit">Save Changes</button>
    </form>
    <a href="manage_accounts.php">← Back to Manage Accounts</a>
</div>
</body>
</html>
