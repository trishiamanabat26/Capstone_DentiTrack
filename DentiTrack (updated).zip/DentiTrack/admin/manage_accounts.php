<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

include '../config/db.php';
$admin_username = $_SESSION['username'];

// Fetch users grouped by role including doctor
$roles = ['patient', 'secretary', 'admin', 'doctor'];
$users_by_role = [];

foreach ($roles as $role) {
    $stmt = $conn->prepare("SELECT user_id, username, role, created_at, updated_at FROM users WHERE role = ?");
    $stmt->bind_param("s", $role);
    $stmt->execute();
    $result = $stmt->get_result();
    $users_by_role[$role] = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Manage Accounts - DentiTrack</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        /* YOUR EXISTING CSS HERE - unchanged */
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: #e6f0ff;
            color: #003366;
            display: flex;
            height: 100vh;
        }
        nav.sidebar {
            width: 220px;
            background: linear-gradient(to bottom, #3399ff, #0066cc);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.15);
            display: flex;
            flex-direction: column;
        }
        
        .sidebar a {
            display: block;
            padding: 14px 24px;
            margin: 10px 15px;
            color: #cce0ff;
            text-decoration: none;
            font-weight: 600;
            border-left: 4px solid transparent;
            transition: all 0.2s ease;
        }
        .sidebar a:hover, .sidebar a.active {
            background: rgba(255,255,255,0.15);
            color: white;
            border-left: 4px solid #ffcc00;
        }
        .sidebar a i {
    margin-right: 10px;
}

        main {
            flex: 1;
            padding: 40px;
            background: white;
            overflow-y: auto;
        }
        h1 {
            color: #004080;
        }
           .sidebar a {
        display: block;
        padding: 14px 24px;
        margin: 10px 15px;
        color: #cce0ff;
        text-decoration: none;
        border-left: 4px solid transparent;
        font-weight: 600;
        font-size: 15px;
        border-radius: 4px;
        transition: background-color 0.3s ease, border-left-color 0.3s ease;
    }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background: #f9fbff;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: left;
            vertical-align: middle;
        }
        th {
            background-color: #dbeaff;
        }
        .actions button {
            padding: 6px 12px;
            margin-right: 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }
        .actions .edit { background: #ffcc00; color: #000; }
        .actions .edit:hover { background: #e6b800; }
        .actions .delete { background: #e74c3c; color: #fff; }
        .actions .delete:hover { background: #c0392b; }
        .filter-box {
            margin-top: 10px;
            margin-bottom: 10px;
        }
        select {
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        button#createBtn {
            padding: 10px 20px;
            background: #3399ff;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }
        button#createBtn:hover {
            background: #2673cc;
        }
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top:0; left:0; width:100%; height:100%;
            background-color: rgba(0,0,0,0.6);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal-content {
            background:#fff;
            padding: 30px;
            border-radius: 10px;
            width: 400px;
            max-width: 90%;
            position: relative;
        }
        .modal-content h2 {
            margin-top: 0;
            color: #004080;
        }
        .modal-content label {
            display: block;
            margin-top: 15px;
            font-weight: 600;
        }
        .modal-content input[type="text"],
        .modal-content input[type="password"],
        .modal-content select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }
        .modal-content button {
            margin-top: 20px;
            padding: 10px 18px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
        }
        .modal-content .save-btn {
            background: #28a745;
            color: white;
            float: right;
            margin-left: 10px;
            transition: background-color 0.3s ease;
        }
        .modal-content .save-btn:hover {
            background: #218838;
        }
        .modal-content .cancel-btn {
            background: #ccc;
            color: black;
            float: right;
            transition: background-color 0.3s ease;
        }
        .modal-content .cancel-btn:hover {
            background: #aaa;
        }
        .close-modal {
            position: absolute;
            right: 15px;
            top: 15px;
            font-size: 22px;
            color: #666;
            cursor: pointer;
            font-weight: bold;
        }
        .close-modal:hover {
            color: #000;
        }
        .clearfix::after {
            content: "";
            display: table;
            clear: both;
        }
    </style>
</head>
<body>
<nav class="sidebar">
    <h2 style="text-align:center;"><i class="fas fa-tooth"></i> DentiTrack</h2>
    <a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="manage_accounts.php" class="active"><i class="fas fa-users-cog"></i> Manage Accounts</a>
 <a href="generate_reports.php"><i class="fas fa-chart-line"></i> Generate Reports</a>
    <a href="payment_module.php"><i class="fas fa-money-check-dollar"></i> Payment Module</a>
     <a href="appointments.php"><i class="fas fa-calendar-check"></i> Appointments</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main>
    <h1>Manage Accounts</h1>
    <p>Welcome, <strong><?= htmlspecialchars($admin_username) ?></strong></p>

    <div class="filter-box">
        <label for="roleFilter"><strong>Filter by Role:</strong></label>
        <select id="roleFilter" onchange="filterAccounts()">
            <option value="all">All</option>
            <option value="patient">Patients</option>
            <option value="secretary">Secretaries</option>
            <option value="admin">Admins</option>
            <option value="doctor">Doctors</option>
        </select>
    </div>

    <div style="margin-bottom: 20px;">
        <button id="createBtn" onclick="openCreateModal()">+ Create Account</button>
    </div>

    <?php foreach ($users_by_role as $role => $users): ?>
        <div class="role-table" id="<?= htmlspecialchars($role) ?>_table">
            <h2><?= ucfirst(htmlspecialchars($role)) ?>s</h2>
            <?php if (count($users) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Username</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= htmlspecialchars($user['user_id']) ?></td>
                                <td><?= htmlspecialchars($user['username']) ?></td>
                                <td><?= htmlspecialchars($user['created_at']) ?></td>
                                <td><?= htmlspecialchars($user['updated_at']) ?></td>
                                <td class="actions">
                                    <button class="edit" onclick="openEditModal(<?= $user['user_id'] ?>, '<?= htmlspecialchars(addslashes($user['username'])) ?>', '<?= $user['role'] ?>')">Edit</button>
                                    <button class="delete" onclick="confirmDelete(<?= $user['user_id'] ?>)">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No <?= htmlspecialchars($role) ?> accounts found.</p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>

    <!-- Create Account Modal -->
    <div id="createModal" class="modal" aria-hidden="true" role="dialog" aria-labelledby="createModalTitle">
        <div class="modal-content">
            <span class="close-modal" onclick="closeCreateModal()" aria-label="Close">&times;</span>
            <h2 id="createModalTitle">Create New Account</h2>
            <form id="createForm" action="save_account.php" method="POST">
                <input type="hidden" name="user_id" value="">
                <label for="createUsername">Username:</label>
                <input type="text" id="createUsername" name="username" required>

                <label for="createPassword">Password:</label>
                <input type="password" id="createPassword" name="password" required>

                <label for="createRole">Role:</label>
                <select id="createRole" name="role" required>
                    <option value="">Select Role</option>
                    <option value="admin">Admin</option>
                    <option value="secretary">Secretary</option>
                    <option value="patient">Patient</option>
                    <option value="doctor">Doctor</option>
                </select>

                <div class="clearfix">
                    <button type="button" class="cancel-btn" onclick="closeCreateModal()">Cancel</button>
                    <button type="submit" class="save-btn">Create</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Account Modal -->
    <div id="editModal" class="modal" aria-hidden="true" role="dialog" aria-labelledby="editModalTitle">
        <div class="modal-content">
            <span class="close-modal" onclick="closeEditModal()" aria-label="Close">&times;</span>
            <h2 id="editModalTitle">Edit Account</h2>
            <form id="editForm" action="save_account.php" method="POST">
                <input type="hidden" id="editUserId" name="user_id" value="">
                <label for="editUsername">Username:</label>
                <input type="text" id="editUsername" name="username" required>

                <label for="editPassword">New Password (leave blank to keep current):</label>
                <input type="password" id="editPassword" name="password">

                <label for="editRole">Role:</label>
                <select id="editRole" name="role" required>
                    <option value="admin">Admin</option>
                    <option value="secretary">Secretary</option>
                    <option value="patient">Patient</option>
                    <option value="doctor">Doctor</option>
                </select>

                <div class="clearfix">
                    <button type="button" class="cancel-btn" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="save-btn">Save</button>
                </div>
            </form>
        </div>
    </div>

</main>

<script>
function filterAccounts() {
    const filter = document.getElementById('roleFilter').value;
    const roles = ['patient', 'secretary', 'admin', 'doctor'];
    roles.forEach(role => {
        const div = document.getElementById(role + '_table');
        if (filter === 'all' || filter === role) {
            div.style.display = 'block';
        } else {
            div.style.display = 'none';
        }
    });
}

function openCreateModal() {
    document.getElementById('createModal').style.display = 'flex';
    document.getElementById('createForm').reset();
}

function closeCreateModal() {
    document.getElementById('createModal').style.display = 'none';
}

function openEditModal(userId, username, role) {
    document.getElementById('editModal').style.display = 'flex';
    document.getElementById('editUserId').value = userId;
    document.getElementById('editUsername').value = username;
    document.getElementById('editPassword').value = '';
    document.getElementById('editRole').value = role;
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

function confirmDelete(userId) {
    if (confirm("Are you sure you want to delete this account? This action cannot be undone.")) {
        window.location.href = "delete_account.php?user_id=" + userId;
    }
}

// Close modals when clicking outside modal content
window.onclick = function(event) {
    const createModal = document.getElementById('createModal');
    const editModal = document.getElementById('editModal');
    if (event.target === createModal) {
        closeCreateModal();
    }
    if (event.target === editModal) {
        closeEditModal();
    }
}
</script>
</body>
</html>
