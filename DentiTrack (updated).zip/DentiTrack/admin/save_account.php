<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

include '../config/db.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // Enable detailed MySQL errors

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $role = $_POST['role'];
    $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : null;

    if ($user_id) {
        // Edit existing
        if (!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET username = ?, password_hash = ?, role = ?, updated_at = NOW() WHERE user_id = ?");
            $stmt->bind_param("sssi", $username, $password, $role, $user_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET username = ?, role = ?, updated_at = NOW() WHERE user_id = ?");
            $stmt->bind_param("ssi", $username, $role, $user_id);
        }
    } else {
        // Create new
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, password_hash, role, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
        $stmt->bind_param("sss", $username, $password, $role);
    }

    if ($stmt->execute()) {
        header('Location: manage_accounts.php?success=1');
    } else {
        echo "Failed to save.";
    }
}
?>
