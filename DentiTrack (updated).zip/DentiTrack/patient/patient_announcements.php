<?php
session_start();
require_once '../config/db_pdo.php';

// Optional: check if patient is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'patient') {
    header("Location: patient_login.php");
    exit;
}

try {
    $stmt = $conn->query("SELECT * FROM announcements ORDER BY posted_at DESC");
    $announcements = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Failed to fetch announcements: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Announcements - DentiTrack</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f0f2f5;
      margin: 0;
      padding: 0;
    }
    header {
      background-color: #007bff;
      color: white;
      padding: 20px;
      font-size: 24px;
      font-weight: bold;
      text-align: center;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .container {
      max-width: 800px;
      margin: 30px auto;
      padding: 0 20px;
    }
    .card {
      background: white;
      border-radius: 12px;
      padding: 20px;
      margin-bottom: 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    .card h2 {
      font-size: 20px;
      color: #007bff;
      margin-bottom: 10px;
    }
    .card p {
      font-size: 16px;
      color: #333;
      margin-bottom: 15px;
    }
    .card .meta {
      font-size: 14px;
      color: #777;
      margin-bottom: 10px;
    }
    .card img {
      max-width: 100%;
      border-radius: 8px;
      margin-top: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    a.back-link {
      display: inline-block;
      margin-top: 20px;
      color: #007bff;
      text-decoration: none;
      font-weight: 600;
    }
    a.back-link:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<header>Patient Dashboard - Announcements</header>

<div class="container">
  <?php if (empty($announcements)): ?>
    <p>No announcements at the moment.</p>
  <?php else: ?>
    <?php foreach ($announcements as $announcement): ?>
      <div class="card">
        <h2><?= htmlspecialchars($announcement['title']) ?></h2>
        <p class="meta">Posted by <?= htmlspecialchars($announcement['posted_by']) ?> on <?= date('F j, Y \a\t g:i A', strtotime($announcement['posted_at'])) ?></p>
        <p><?= nl2br(htmlspecialchars($announcement['content'])) ?></p>
        <?php if (!empty($announcement['image'])): ?>
          <img src="../uploads/announcements/<?= htmlspecialchars($announcement['image']) ?>" alt="Announcement Image" />
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>

  <a href="patient_dashboard.php" class="back-link">&larr; Back to Dashboard</a>
</div>

</body>
</html>
