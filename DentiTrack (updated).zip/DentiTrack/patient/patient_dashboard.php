<?php
session_start();
if (!isset($_SESSION['patient_id'])) {
    header("Location: patient_login.php");
    exit;
}

include '../config/db.php';

$patient_id = $_SESSION['patient_id'];

// Fetch patient info
$sql_patient = "SELECT full_name FROM patient WHERE patient_id = ?";
$stmt = $conn->prepare($sql_patient);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
$patient = $result->fetch_assoc();
$stmt->close();

// Fetch next upcoming appointment
$sql_next_appointment = "SELECT appointment_date, appointment_time, status 
                         FROM appointments 
                         WHERE patient_id = ? AND appointment_date >= CURDATE() 
                         ORDER BY appointment_date ASC LIMIT 1";
$stmt = $conn->prepare($sql_next_appointment);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$next_appointment = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Count upcoming appointments
$sql_upcoming_count = "SELECT COUNT(*) as count FROM appointments WHERE patient_id = ? AND appointment_date >= CURDATE()";
$stmt = $conn->prepare($sql_upcoming_count);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$upcoming_count = $stmt->get_result()->fetch_assoc()['count'];
$stmt->close();

// Count announcements
$sql_announcements_count = "SELECT COUNT(*) as count FROM announcements";
$result = $conn->query($sql_announcements_count);
if (!$result) {
    die("Query failed: " . $conn->error);
}
$announcements_count = $result->fetch_assoc()['count'];

// Get last dental record date
$sql_last_record = "SELECT record_date FROM dental_records WHERE patient_id = ? ORDER BY record_date DESC LIMIT 1";
$stmt = $conn->prepare($sql_last_record);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$last_record = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Count dental records
$sql_records_count = "SELECT COUNT(*) as count FROM dental_records WHERE patient_id = ?";
$stmt = $conn->prepare($sql_records_count);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$records_count = $stmt->get_result()->fetch_assoc()['count'];
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Patient Dashboard - DentiTrack</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <style>
        html { scroll-behavior: smooth; }
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: #e6f0ff;
            color: #003366;
            height: 100vh;
            display: flex;
        }
        .sidebar {
            width: 220px;
            background: linear-gradient(to bottom, #3399ff, #0066cc);
            padding: 20px;
            color: white;
            box-shadow: 2px 0 10px rgba(0,0,0,0.15);
            display: flex;
            flex-direction: column;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 24px;
            font-weight: 700;
            user-select: none;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
        }
        .sidebar a {
            display: block;
            padding: 12px 20px;
            margin: 10px 0;
            color: #cce0ff;
            text-decoration: none;
            border-left: 4px solid transparent;
            font-weight: 600;
            transition: background-color 0.3s ease, border-left-color 0.3s ease;
        }
        .sidebar a:hover, .sidebar a.active {
            background-color: rgba(255,255,255,0.15);
            color: white;
            border-left: 4px solid #ffcc00;
        }
        .main-content {
            flex: 1;
            padding: 40px;
            background: white;
            overflow-y: auto;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        header h1 {
            font-size: 2rem;
            color: #004080;
            text-shadow: 1px 1px 2px #a3c2ff;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .welcome {
            font-size: 1.3rem;
            margin-bottom: 2rem;
            font-weight: 600;
        }
        .widgets {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }
        .widget {
            background: #f0f7ff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
            text-align: left;
            cursor: pointer;
            transition: transform 0.3s ease, background-color 0.3s ease;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        .widget:hover {
            transform: translateY(-5px);
            background-color: #d9e8ff;
        }
        .widget i {
            font-size: 36px;
            color: #004080;
            margin-bottom: 10px;
        }
        .widget .title {
            font-size: 18px;
            font-weight: 700;
            color: #003366;
        }
        .widget .value {
            font-size: 40px;
            font-weight: 900;
            color: #004080;
        }
        .widget .subtitle {
            font-size: 14px;
            color: #666;
            font-weight: 500;
        }
        #oral-care-section {
            margin-top: 40px;
            background: #eaf4ff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.05);
        }
        #oral-care-section h2 {
            font-size: 1.8rem;
            color: #004080;
            margin-bottom: 20px;
        }
        #oral-care-section p {
            font-size: 1rem;
            color: #333;
            line-height: 1.6;
        }
    </style>
</head>
<body>
    <nav class="sidebar">
        <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
        <a href="patient_dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a>
        <a href="patient_appointments.php"><i class="fas fa-calendar-check"></i> Appointments</a>
        <a href="patient_records.php"><i class="fas fa-file-medical"></i> Dental Records</a>
        <a href="patient_announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="#oral-care-section"><i class="fas fa-heartbeat"></i> Oral Care Tips</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>

    <main class="main-content">
        <header>
            <h1><i class="fas fa-tooth"></i> Patient Dashboard</h1>
        </header>

        <p class="welcome">Welcome, <strong><?= htmlspecialchars($patient['full_name']) ?></strong>!</p>

        <div class="widgets">
            <div class="widget" onclick="location.href='patient_appointments.php'">
                <i class="fas fa-calendar-check"></i>
                <div class="title">Upcoming Appointments</div>
                <div class="value"><?= $upcoming_count ?></div>
                <?php if ($next_appointment): ?>
                    <div class="subtitle">
                        Next: <?= htmlspecialchars($next_appointment['appointment_date']) ?> at <?= htmlspecialchars($next_appointment['appointment_time']) ?> (<?= ucfirst(htmlspecialchars($next_appointment['status'])) ?>)
                    </div>
                <?php else: ?>
                    <div class="subtitle">No upcoming appointments</div>
                <?php endif; ?>
            </div>

            <div class="widget" onclick="location.href='patient_announcements.php'">
                <i class="fas fa-bullhorn"></i>
                <div class="title">Clinic Announcements</div>
                <div class="value"><?= $announcements_count ?></div>
                <div class="subtitle">Latest updates and news</div>
            </div>

            <div class="widget" onclick="location.href='patient_records.php'">
                <i class="fas fa-file-medical"></i>
                <div class="title">Dental Records</div>
                <div class="value"><?= $records_count ?></div>
                <?php if ($last_record): ?>
                    <div class="subtitle">Last record: <?= htmlspecialchars($last_record['record_date']) ?></div>
                <?php else: ?>
                    <div class="subtitle">No records found</div>
                <?php endif; ?>
            </div>
        </div>

        <section id="oral-care-section">
            <h2><i class="fas fa-heartbeat"></i> Oral Care Recommendations</h2>
            <p>
                Based on your profile and recent dental visits, here are some tips:
            </p>
            <ul>
                <li>🪥 Brush twice daily with fluoride toothpaste.</li>
                <li>🧵 Floss daily to remove plaque between teeth.</li>
                <li>🍎 Avoid sugary snacks and acidic beverages.</li>
                <li>🦷 Schedule regular cleanings every 6 months.</li>
                <li>💧 Stay hydrated and maintain a healthy diet.</li>
            </ul>
            <p><strong>Note:</strong> These recommendations are general. Please consult your dentist for personalized advice during your appointment.</p>
        </section>
    </main>
</body>
</html>
