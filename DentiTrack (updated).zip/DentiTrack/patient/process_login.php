<?php
// process_login.php

session_start();
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $role = $_POST['role'] ?? '';

    if ($role !== 'patient') {
        echo "Invalid role.";
        exit();
    }

    // Step 1: Authenticate user from 'users' table
    $sql = "SELECT user_id, username, password_hash, role FROM users WHERE username = ? AND role = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
    }

    $stmt->bind_param("ss", $username, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $user_id = $user['user_id'];

        // Step 2: Verify password
        
        if (password_verify($password, $user['password_hash'])) {
            // Step 3: Fetch patient info from 'patient' table using user_id
            $sql2 = "SELECT patient_id, full_name FROM patient WHERE user_id = ?";
            $stmt2 = $conn->prepare($sql2);
            $stmt2->bind_param("i", $user_id);
            $stmt2->execute();
            $result2 = $stmt2->get_result();

            if ($result2->num_rows === 1) {
                $patient = $result2->fetch_assoc();

                // Step 4: Set session variables
                $_SESSION['user_id'] = $user_id;
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['patient_id'] = $patient['patient_id'];
                $_SESSION['fullname'] = $patient['full_name'];

                // Redirect to patient dashboard
                header("Location: patient_dashboard.php");
                exit();
            } else {
                echo "Patient record not found.";
            }

            $stmt2->close();
        } else {
            echo "Incorrect password.";
        }
    } else {
        echo "User not found.";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>
