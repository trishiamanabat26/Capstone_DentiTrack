<?php
// process_register.php

session_start();
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize form inputs
    $fullname = trim($_POST['fullname']);
    $age = (int) $_POST['age'];
    $contact = trim($_POST['contact']);
    $email = trim($_POST['email']);
    $gender = $_POST['gender'];
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = 'patient'; // Fixed role for patient

    // Basic validation
    if ($password !== $confirm_password) {
        echo "Passwords do not match.";
        exit();
    }

    // Check if username or email already exists
    $sql_check = "SELECT patient_id FROM patients WHERE username = ? OR email = ?";
    $stmt_check = $conn->prepare($sql_check);
    if (!$stmt_check) {
        die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
    }
    $stmt_check->bind_param("ss", $username, $email);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        echo "Username or email already exists.";
        exit();
    }
    $stmt_check->close();

    // Hash the password securely
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Insert new patient record
    $sql_insert = "INSERT INTO patients (fullname, age, contact, email, gender, username, password_hash, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    if (!$stmt_insert) {
        die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
    }
    $stmt_insert->bind_param("sissssss", $fullname, $age, $contact, $email, $gender, $username, $password_hash, $role);

    if ($stmt_insert->execute()) {
        // Registration success - redirect to login or dashboard
        header("Location: patient_login.php?register=success");
        exit();
    } else {
        echo "Error: " . $stmt_insert->error;
    }

    $stmt_insert->close();
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>
