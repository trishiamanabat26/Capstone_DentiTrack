<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: secretary_login.php');
    exit();
}

include '../config/db_pdo.php'; // $conn = PDO connection

$secretary_username = $_SESSION['username'];
$message = '';
$errors = [];
// Preserve form values after submit
$old = [
    'full_name' => '',
    'dob' => '',
    'contact_info' => '',
    'medical_history' => '',
    'treatment_records' => '',
    'prescriptions' => '',
    'username' => '',
    'role' => 'patient'
];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Trim and sanitize inputs
    $full_name = trim($_POST['full_name'] ?? '');
    $dob = $_POST['dob'] ?? '';
    $contact_info = trim($_POST['contact_info'] ?? '');
    $medical_history = trim($_POST['medical_history'] ?? '');
    $treatment_records = trim($_POST['treatment_records'] ?? '');
    $prescriptions = trim($_POST['prescriptions'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'patient';

    // Store old values
    $old = compact('full_name', 'dob', 'contact_info', 'medical_history', 'treatment_records', 'prescriptions', 'username', 'role');

    // Validate required fields
    if ($full_name === '') $errors[] = "Full name is required.";
    if ($dob === '') $errors[] = "Date of birth is required.";
    if ($contact_info === '') $errors[] = "Contact info is required.";
    if ($username === '') $errors[] = "Username is required.";
    if ($password === '') $errors[] = "Password is required.";
    if ($role !== 'patient') $errors[] = "Invalid role selected.";

    if (!$errors) {
        try {
            // Check if username exists in users table
            $checkStmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE username = :username");
            $checkStmt->execute([':username' => $username]);
            if ($checkStmt->fetchColumn() > 0) {
                $errors[] = "Username already exists. Please choose another.";
            } else {
                // Insert into users table
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $conn->beginTransaction();

                $insertUser = $conn->prepare("INSERT INTO users (username, password_hash, role, created_at, updated_at)
                                             VALUES (:username, :password_hash, :role, NOW(), NOW())");
                $insertUser->execute([
                    ':username' => $username,
                    ':password_hash' => $password_hash,
                    ':role' => $role
                ]);

                $user_id = $conn->lastInsertId();

                // Insert into patient table
                $insertPatient = $conn->prepare("INSERT INTO patient 
                    (user_id, full_name, dob, contact_info, medical_history, treatment_records, prescriptions, created_at, updated_at)
                    VALUES
                    (:user_id, :full_name, :dob, :contact_info, :medical_history, :treatment_records, :prescriptions, NOW(), NOW())");

                $insertPatient->execute([
                    ':user_id' => $user_id,
                    ':full_name' => $full_name,
                    ':dob' => $dob,
                    ':contact_info' => $contact_info,
                    ':medical_history' => $medical_history,
                    ':treatment_records' => $treatment_records,
                    ':prescriptions' => $prescriptions
                ]);

                $conn->commit();

                $message = "Patient added successfully!";
                // Clear old values
                $old = array_map(fn($v) => '', $old);
            }
        } catch (PDOException $e) {
            $conn->rollBack();
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Add Patient - DentiTrack</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" />
<style>
    html { scroll-behavior: smooth; }
    body {
        margin: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #e6f0ff;
        color: #003366;
        display: flex;
        height: 100vh;
        flex-direction: row;
    }
    .sidebar {
        width: 220px;
        background: linear-gradient(to bottom, #3399ff, #0066cc);
        padding: 20px;
        color: white;
        box-shadow: 2px 0 10px rgba(0,0,0,0.15);
        display: flex;
        flex-direction: column;
    }
    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
        font-weight: 700;
    }
    .sidebar a {
        display: block;
        padding: 12px 20px;
        margin: 10px 0;
        color: #cce0ff;
        text-decoration: none;
        border-left: 4px solid transparent;
        font-weight: 600;
        transition: 0.3s ease;
        border-radius: 6px 0 0 6px;
    }
    .sidebar a:hover, .sidebar a.active {
        background-color: rgba(255,255,255,0.15);
        border-left: 4px solid #ffcc00;
        color: white;
    }

    main.main-content {
        flex: 1;
        padding: 40px 60px;
        background: white;
        border-radius: 0 20px 20px 0;
        box-shadow: 4px 0 20px rgba(0,0,0,0.1);
        display: flex;
        flex-direction: column;
        overflow-y: auto;
        justify-content: flex-start;
    }
    header h1 {
        font-size: 2.2rem;
        color: #004080;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-bottom: 0.5rem;
    }
    .welcome {
        font-size: 1.2rem;
        margin-bottom: 1rem;
        font-weight: 600;
    }
    .message {
        padding: 15px;
        margin-bottom: 20px;
        border-radius: 10px;
        background: #d9e8ff;
        color: #004080;
        font-weight: bold;
        text-align: center;
    }
    .error-list {
        background: #ffd6d6;
        border: 1px solid #ff4d4d;
        padding: 15px 20px;
        margin-bottom: 20px;
        border-radius: 10px;
        color: #b30000;
        font-weight: 600;
    }
    .toggle-btn {
        padding: 14px 28px;
        margin-bottom: 30px;
        font-size: 18px;
        background-color: #3399ff;
        border: none;
        border-radius: 14px;
        color: white;
        cursor: pointer;
        transition: 0.3s ease;
        font-weight: 700;
        width: fit-content;
        box-shadow: 0 6px 16px rgba(0,102,204,0.3);
        align-self: flex-start;
    }
    .toggle-btn:hover {
        background-color: #0066cc;
    }

    form {
        background: #f0f7ff;
        padding: 40px 50px;
        border-radius: 24px;
        box-shadow: 0 12px 36px rgba(0, 102, 204, 0.18);
        display: none;
        flex-direction: row;
        flex-wrap: wrap;
        gap: 30px 60px;
        max-width: 900px;
        margin: 0 auto;
        align-items: flex-start;
    }
    form.show {
        display: flex;
        animation: slideIn 0.4s ease forwards;
    }

    @keyframes slideIn {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .form-group {
        display: flex;
        flex-direction: column;
        flex: 1 1 40%;
        min-width: 280px;
    }

    label {
        font-weight: 600;
        color: #003366;
        margin-bottom: 10px;
        font-size: 1rem;
    }
    input[type="text"], input[type="date"], input[type="password"], textarea, select {
        padding: 14px 18px;
        border: 1.5px solid #b3c6ff;
        border-radius: 14px;
        font-size: 16px;
        transition: 0.3s ease;
        resize: vertical;
        box-shadow: inset 0 2px 4px #d7e3ff;
        background: white;
    }
    input:focus, textarea:focus, select:focus {
        border-color: #3399ff;
        box-shadow: 0 0 12px #3399ff88;
        outline: none;
    }
    textarea {
        min-height: 100px;
    }
    button[type="submit"] {
        background: #0066cc;
        color: white;
        padding: 16px 28px;
        font-size: 18px;
        border: none;
        border-radius: 20px;
        cursor: pointer;
        transition: 0.3s;
        font-weight: 700;
        box-shadow: 0 8px 22px rgba(0, 102, 204, 0.35);
        align-self: flex-start;
        margin-top: 10px;
        flex: none;
    }
    button[type="submit"]:hover {
        background: #004080;
    }
    form hr {
        width: 100%;
        border-color: #c4d2ff;
        margin: 40px 0 20px 0;
    }
    @media (max-width: 800px) {
        form {
            flex-direction: column;
            padding: 30px 30px;
            max-width: 100%;
        }
        .form-group {
            flex: 1 1 100%;
        }
        button[type="submit"] {
            width: 100%;
        }
    }
</style>
<script>
    function toggleForm() {
        const form = document.getElementById('patientForm');
        form.classList.toggle('show');
    }

    // Optionally, auto-show form if errors/messages exist
    window.onload = function() {
        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
            toggleForm();
        <?php endif; ?>
    }
</script>
</head>
<body>


    <nav class="sidebar">
        <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
        <a href="dashboard.php" ><i class="fas fa-home"></i> Dashboard</a>
        <a href="add_patient.php"class="active"><i class="fas fa-user-plus"></i> Add Patient</a>
        <a href="view_patients.php"><i class="fas fa-users"></i> View Patients</a>
        <a href="view_appointments.php"><i class="fas fa-calendar-check"></i> Appointments</a>
        <a href="create_announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>

<main class="main-content">
    <header>
        <h1><i class="fas fa-user-plus"></i> Add Patient</h1>
        <div class="welcome">Logged in as <strong><?php echo htmlspecialchars($secretary_username); ?></strong></div>
    </header>

    <?php if ($message): ?>
        <div class="message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <?php if ($errors): ?>
        <div class="error-list">
            <ul>
                <?php foreach ($errors as $err): ?>
                    <li><?php echo htmlspecialchars($err); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <button class="toggle-btn" type="button" onclick="toggleForm()">
        <i class="fas fa-plus-circle"></i> Add New Patient
    </button>

    <form id="patientForm" method="post" autocomplete="off" novalidate>
        <!-- Patient Clinical Info -->
        <div class="form-group">
            <label for="full_name">Full Name <sup style="color:#cc0000">*</sup></label>
            <input type="text" id="full_name" name="full_name" required value="<?php echo htmlspecialchars($old['full_name']); ?>" />
        </div>

        <div class="form-group">
            <label for="dob">Date of Birth <sup style="color:#cc0000">*</sup></label>
            <input type="date" id="dob" name="dob" required value="<?php echo htmlspecialchars($old['dob']); ?>" />
        </div>

        <div class="form-group">
            <label for="contact_info">Contact Info <sup style="color:#cc0000">*</sup></label>
            <input type="text" id="contact_info" name="contact_info" required value="<?php echo htmlspecialchars($old['contact_info']); ?>" />
        </div>

        <div class="form-group" style="flex: 1 1 100%;">
            <label for="medical_history">Medical History</label>
            <textarea id="medical_history" name="medical_history" rows="4"><?php echo htmlspecialchars($old['medical_history']); ?></textarea>
        </div>

        <div class="form-group" style="flex: 1 1 100%;">
            <label for="treatment_records">Treatment Records</label>
            <textarea id="treatment_records" name="treatment_records" rows="4"><?php echo htmlspecialchars($old['treatment_records']); ?></textarea>
        </div>

        <div class="form-group" style="flex: 1 1 100%;">
            <label for="prescriptions">Prescriptions</label>
            <textarea id="prescriptions" name="prescriptions" rows="4"><?php echo htmlspecialchars($old['prescriptions']); ?></textarea>
        </div>

        <hr />

        <!-- User Account Info -->
        <div class="form-group">
            <label for="username">Username <sup style="color:#cc0000">*</sup></label>
            <input type="text" id="username" name="username" required minlength="4" maxlength="50" value="<?php echo htmlspecialchars($old['username']); ?>" />
        </div>

        <div class="form-group">
            <label for="password">Password <sup style="color:#cc0000">*</sup></label>
            <input type="password" id="password" name="password" required minlength="6" />
        </div>

        <div class="form-group">
            <label for="role">Role</label>
            <select id="role" name="role" disabled>
                <option value="patient" selected>Patient</option>
            </select>
        </div>

        <button type="submit"><i class="fas fa-check-circle"></i> Submit</button>
    </form>
</main>
</body>
</html>
