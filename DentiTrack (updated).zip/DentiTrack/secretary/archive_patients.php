<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: secretary_login.php');
    exit();
}

include '../config/db_pdo.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: view_patients.php?error=invalid_id');
    exit();
}

$patient_id = (int)$_GET['id'];

try {
    $conn->beginTransaction();

    // Fetch patient data
    $stmt = $conn->prepare("SELECT * FROM patient WHERE patient_id = :id");
    $stmt->execute([':id' => $patient_id]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$patient) {
        $conn->rollBack();
        die("Patient not found with ID: $patient_id");
    }

    // Insert into patient_archive table
    $insert = $conn->prepare("INSERT INTO patient_archive (patient_id, full_name, dob, contact_info, address, archived_at) VALUES (:patient_id, :full_name, :dob, :contact_info, :address, NOW())");
    $insert->execute([
        ':patient_id' => $patient['patient_id'],
        ':full_name' => $patient['full_name'],
        ':dob' => $patient['dob'],
        ':contact_info' => $patient['contact_info'],
        ':address' => $patient['address'],
    ]);

    // Delete from patients
    $delete = $conn->prepare("DELETE FROM patient WHERE patient_id = :id");
    $delete->execute([':id' => $patient_id]);

    $conn->commit();

    header('Location: view_patients.php?success=archived');
    exit();

} catch (Exception $e) {
    $conn->rollBack();
    echo "Error archiving patient: " . $e->getMessage();
}
