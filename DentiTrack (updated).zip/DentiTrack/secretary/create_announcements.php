<?php
session_start();
require_once '../config/db_pdo.php';
$pdo = $conn;

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'secretary') {
    header('Location: secretary_login.php');
    exit;
}

$error = '';
$success = '';
$title = '';
$content = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $posted_by = $_SESSION['username'] ?? 'Secretary';

    $imageName = null;
    if (!empty($_FILES['image']['name'])) {
        $allowedTypes = ['image/jpeg', 'image/png'];
        $maxFileSize = 2 * 1024 * 1024;

        $imageTmpName = $_FILES['image']['tmp_name'];
        $imageType = mime_content_type($imageTmpName);
        $imageSize = $_FILES['image']['size'];

        if (!in_array($imageType, $allowedTypes)) {
            $error = "Only JPG and PNG images are allowed.";
        } elseif ($imageSize > $maxFileSize) {
            $error = "Image size must be less than 2MB.";
        } else {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $imageName = uniqid('ann_') . '.' . $ext;
            $uploadDir = __DIR__ . '/../uploads/announcements/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            $uploadPath = $uploadDir . $imageName;

            if (!move_uploaded_file($imageTmpName, $uploadPath)) {
                $error = "Failed to upload image.";
            }
        }
    }

    if (empty($error)) {
        if (empty($title) || empty($content)) {
            $error = "Please fill in all required fields.";
        } else {
            try {
                $sql = "INSERT INTO announcements (title, content, posted_by, posted_at, image) VALUES (?, ?, ?, NOW(), ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$title, $content, $posted_by, $imageName]);
                $success = "Announcement created successfully.";
                $title = $content = '';
            } catch (Exception $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Create Announcement - Secretary</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" />
  <style>
    body { margin: 0; }
    .sidebar {
      width: 220px;
      background: linear-gradient(to bottom, #3399ff, #0066cc);
      padding: 20px;
      color: white;
      display: flex;
      flex-direction: column;
      height: 100vh;
      position: fixed;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .sidebar h2 { text-align: center; margin-bottom: 30px; font-size: 24px; }
    .sidebar a {
      padding: 12px 20px;
      margin: 10px 0;
      color: #cce0ff;
      text-decoration: none;
      border-left: 4px solid transparent;
      font-weight: 600;
      display: block;
      border-radius: 6px 0 0 6px;
    }
    .sidebar a:hover,
    .sidebar a.active {
      background-color: rgba(255,255,255,0.15);
      border-left: 4px solid #ffcc00;
      color: white;
    }
    main.main-content {
      margin-left: 240px;
      padding: 40px 60px;
      background: #f0f2f5;
      min-height: 100vh;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #333;
    }
    h1 { color: #007bff; }
    form label {
      display: block;
      margin-bottom: 6px;
      font-weight: 600;
    }
    form input[type="text"],
    form textarea,
    form input[type="file"] {
      width: 100%;
      padding: 10px 12px;
      border: 1.5px solid #ccc;
      border-radius: 7px;
      margin-bottom: 20px;
      font-size: 16px;
    }
    button {
      background-color: #007bff;
      color: white;
      padding: 12px 20px;
      border: none;
      border-radius: 7px;
      font-size: 18px;
      font-weight: 700;
      cursor: pointer;
    }
    button:hover { background-color: #0056b3; }
    .message {
      font-weight: 700;
      padding: 12px 15px;
      border-radius: 7px;
      margin-bottom: 20px;
      text-align: center;
    }
    .error { background-color: #ffdddd; color: #cc0000; }
    .success { background-color: #ddffdd; color: #008800; }
    #imagePreview {
      display: none;
      margin-bottom: 20px;
      max-width: 100%;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 30px;
      background: #fff;
      border-radius: 8px;
      overflow: hidden;
    }
    table th, table td {
      padding: 12px;
      border-bottom: 1px solid #ddd;
      text-align: left;
    }
    table th {
      background-color: #007bff;
      color: white;
    }
    table tr:hover {
      background-color: #f5f5f5;
    }
    .history-section h2 {
      margin-top: 60px;
      color: #0056b3;
    }
  </style>
</head>
<body>

<nav class="sidebar">
  <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
  <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
  <a href="add_patient.php"><i class="fas fa-user-plus"></i> Add Patient</a>
  <a href="view_patients.php"><i class="fas fa-users"></i> View Patients</a>
  <a href="view_appointments.php"><i class="fas fa-calendar-check"></i> Appointments</a>
  <a href="create_announcements.php" class="active"><i class="fas fa-bullhorn"></i> Announcements</a>
  <a href="inventory.php"><i class="fas fa-boxes"></i> Inventory</a>
  <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>

<main class="main-content">
  <h1>Create Announcement</h1>

  <?php if ($error): ?>
    <div class="message error"><?= htmlspecialchars($error) ?></div>
  <?php elseif ($success): ?>
    <div class="message success"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data">
    <label for="title">Title</label>
    <input type="text" id="title" name="title" value="<?= htmlspecialchars($title) ?>" required />

    <label for="content">Content</label>
    <textarea id="content" name="content" rows="6" required><?= htmlspecialchars($content) ?></textarea>

    <label for="image">Attach Image (optional)</label>
    <input type="file" id="image" name="image" accept="image/png, image/jpeg" />
    <img id="imagePreview" alt="Image Preview" />

    <button type="submit">Publish Announcement</button>
  </form>

  <!-- ANNOUNCEMENT HISTORY SECTION -->
  <div class="history-section">
    <h2>Announcement History</h2>
    <table>
      <thead>
        <tr>
          <th>Title</th>
          <th>Content</th>
          <th>Posted By</th>
          <th>Date</th>
          <th>Image</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $stmt = $pdo->query("SELECT * FROM announcements ORDER BY posted_at DESC");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
          <tr>
            <td><?= htmlspecialchars($row['title']) ?></td>
            <td><?= nl2br(htmlspecialchars(substr($row['content'], 0, 100))) ?>...</td>
            <td><?= htmlspecialchars($row['posted_by']) ?></td>
            <td><?= date('M d, Y H:i', strtotime($row['posted_at'])) ?></td>
            <td>
              <?php if (!empty($row['image'])): ?>
                <img src="../uploads/announcements/<?= htmlspecialchars($row['image']) ?>" alt="Image" style="max-width: 80px; border-radius: 6px;" />
              <?php else: ?>
                <em>No image</em>
              <?php endif; ?>
            </td>
            
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</main>

<script>
  const imageInput = document.getElementById('image');
  const imagePreview = document.getElementById('imagePreview');

  imageInput.addEventListener('change', () => {
    const file = imageInput.files[0];
    if (file) {
      const allowedTypes = ['image/jpeg', 'image/png'];
      if (!allowedTypes.includes(file.type)) {
        alert('Only JPG and PNG images are allowed.');
        imageInput.value = '';
        imagePreview.style.display = 'none';
        return;
      }
      if (file.size > 2 * 1024 * 1024) {
        alert('Image size must be less than 2MB.');
        imageInput.value = '';
        imagePreview.style.display = 'none';
        return;
      }
      const reader = new FileReader();
      reader.onload = e => {
        imagePreview.src = e.target.result;
        imagePreview.style.display = 'block';
      };
      reader.readAsDataURL(file);
    } else {
      imagePreview.style.display = 'none';
    }
  });
</script>

</body>
</html>
