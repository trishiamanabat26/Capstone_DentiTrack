<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: secretary_login.php');
    exit();
}

include '../config/db_pdo.php';

$patient_id = $_GET['id'] ?? '';
if (!$patient_id) {
    header('Location: view_patients.php');
    exit();
}

// Fetch patient details joined with user account
$sql = "SELECT p.*, u.user_id, u.username
        FROM patient p
        JOIN users u ON p.user_id = u.user_id
        WHERE p.patient_id = :id";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $patient_id, PDO::PARAM_INT);
$stmt->execute();
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
    echo "Patient not found.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $full_name = trim($_POST['full_name']);
    $dob = trim($_POST['dob']);
    $contact_info = trim($_POST['contact_info']);
    $username = trim($_POST['username']);
    $password = $_POST['password'] ?? '';

    // Update patient info
    $updatePatient = $conn->prepare("UPDATE patient SET full_name = :full_name, dob = :dob, contact_info = :contact_info WHERE patient_id = :id");
    $updatePatient->execute([
        ':full_name' => $full_name,
        ':dob' => $dob,
        ':contact_info' => $contact_info,
        ':id' => $patient_id
    ]);

    // Update user account username and password (if password not empty)
    if ($username !== '') {
        if ($password !== '') {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $updateUser = $conn->prepare("UPDATE users SET username = :username, password_hash = :password_hash WHERE user_id = :uid");
            $updateUser->execute([
                ':username' => $username,
                ':password_hash' => $password_hash,
                ':uid' => $patient['user_id']
            ]);
        } else {
            $updateUser = $conn->prepare("UPDATE users SET username = :username WHERE user_id = :uid");
            $updateUser->execute([
                ':username' => $username,
                ':uid' => $patient['user_id']
            ]);
        }
    }

    header("Location: view_patients.php?message=updated");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Edit Patient & Account - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" />
<style>
body {
    margin: 0; font-family: 'Segoe UI', sans-serif;
    background: #e6f0ff; color: #003366;
    display: flex; justify-content: center; align-items: center; min-height: 100vh;
}
.container {
    background: white; padding: 40px; border-radius: 20px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.1); width: 420px;
}
h2 {
    text-align: center; font-size: 1.8rem; margin-bottom: 30px;
    color: #004080; text-shadow: 1px 1px 2px #a3c2ff;
}
form label {
    display: block; font-weight: 600; margin-bottom: 8px; color: #003366;
}
form input[type="text"],
form input[type="date"],
form input[type="password"] {
    width: 100%; padding: 12px 15px; border-radius: 12px;
    border: 1.5px solid #b3c6ff; font-size: 16px; margin-bottom: 20px;
    transition: border-color 0.3s ease;
}
form input:focus {
    border-color: #3399ff; outline: none; box-shadow: 0 0 8px #3399ff88;
}
form button {
    width: 100%; background-color: #0066cc; color: white;
    font-weight: 700; font-size: 16px; padding: 12px;
    border: none; border-radius: 12px; cursor: pointer;
    box-shadow: 0 4px 10px rgba(0,102,204,0.4);
    transition: background-color 0.3s ease;
}
form button:hover {
    background-color: #004080;
    box-shadow: 0 6px 12px rgba(0,64,128,0.6);
}
a.back-link {
    display: inline-block; margin-top: 20px; text-align: center;
    width: 100%; text-decoration: none; color: #0066cc;
    font-weight: 700; border: 1.5px solid #0066cc;
    padding: 10px 0; border-radius: 12px;
    transition: background-color 0.3s ease, color 0.3s ease;
}
a.back-link:hover {
    background-color: #0066cc; color: white;
}
</style>
</head>
<body>

<div class="container">
    <h2><i class="fas fa-user-edit"></i> Edit Patient & Account</h2>
    <form method="POST" novalidate>
        <label for="full_name">Full Name:</label>
        <input id="full_name" type="text" name="full_name" value="<?= htmlspecialchars($patient['full_name']) ?>" required>

        <label for="dob">Date of Birth:</label>
        <input id="dob" type="date" name="dob" value="<?= htmlspecialchars($patient['dob']) ?>" required>

        <label for="contact_info">Contact Info:</label>
        <input id="contact_info" type="text" name="contact_info" value="<?= htmlspecialchars($patient['contact_info']) ?>" required>

        <hr style="margin: 30px 0; border-color: #b3c6ff;" />

        <label for="username">Account Username:</label>
        <input id="username" type="text" name="username" value="<?= htmlspecialchars($patient['username']) ?>" required>

        <label for="password">Account Password (leave blank to keep current):</label>
        <input id="password" type="password" name="password" autocomplete="new-password">

        <button type="submit"><i class="fas fa-save"></i> Update Patient & Account</button>
    </form>

    <a href="view_patients.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Patients List</a>
</div>

</body>
</html>
