<?php
session_start();
include '../config/db_pdo.php';

// Check secretary role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: secretary_login.php');
    exit();
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $quantity = intval($_POST['quantity'] ?? 0);
        $unit = trim($_POST['unit'] ?? 'pcs');
        $expiration_date = $_POST['expiration_date'] ?? null;
        $low_stock_threshold = intval($_POST['low_stock_threshold'] ?? 5);

        if ($name === '' || $quantity < 0 || $low_stock_threshold < 0) {
            $error = "Please fill out all required fields correctly.";
        } else {
            $check = $conn->prepare("SELECT COUNT(*) FROM dental_supplies WHERE name = :name");
            $check->bindValue(':name', $name);
            $check->execute();
            if ($check->fetchColumn() > 0) {
                $error = "Supply with this name already exists.";
            } else {
                $sql = "INSERT INTO dental_supplies (name, description, quantity, unit, expiration_date, low_stock_threshold)
                        VALUES (:name, :description, :quantity, :unit, :expiration_date, :low_stock_threshold)";
                $stmt = $conn->prepare($sql);
                $stmt->bindValue(':name', $name);
                $stmt->bindValue(':description', $description);
                $stmt->bindValue(':quantity', $quantity, PDO::PARAM_INT);
                $stmt->bindValue(':unit', $unit);
                if ($expiration_date) {
                    $stmt->bindValue(':expiration_date', $expiration_date);
                } else {
                    $stmt->bindValue(':expiration_date', null, PDO::PARAM_NULL);
                }
                $stmt->bindValue(':low_stock_threshold', $low_stock_threshold, PDO::PARAM_INT);

                if ($stmt->execute()) {
                    $message = "Supply added successfully.";
                } else {
                    $error = "Failed to add supply.";
                }
            }
        }
    } elseif ($action === 'update') {
        $supply_id = intval($_POST['supply_id'] ?? 0);
        $quantity = intval($_POST['quantity'] ?? 0);
        $low_stock_threshold = intval($_POST['low_stock_threshold'] ?? 5);

        if ($supply_id <= 0 || $quantity < 0 || $low_stock_threshold < 0) {
            $error = "Invalid input for update.";
        } else {
            $sql = "UPDATE dental_supplies SET quantity = :quantity, low_stock_threshold = :low_stock_threshold WHERE supply_id = :supply_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindValue(':quantity', $quantity, PDO::PARAM_INT);
            $stmt->bindValue(':low_stock_threshold', $low_stock_threshold, PDO::PARAM_INT);
            $stmt->bindValue(':supply_id', $supply_id, PDO::PARAM_INT);

            if ($stmt->execute()) {
                $message = "Supply updated successfully.";
            } else {
                $error = "Failed to update supply.";
            }
        }
    } elseif ($action === 'delete') {
        $supply_id = intval($_POST['supply_id'] ?? 0);
        if ($supply_id > 0) {
            $sql = "DELETE FROM dental_supplies WHERE supply_id = :supply_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindValue(':supply_id', $supply_id, PDO::PARAM_INT);
            if ($stmt->execute()) {
                $message = "Supply deleted successfully.";
            } else {
                $error = "Failed to delete supply.";
            }
        } else {
            $error = "Invalid supply ID for deletion.";
        }
    }
}

$sql = "SELECT * FROM dental_supplies ORDER BY expiration_date ASC, name ASC";
$supplies = $conn->query($sql)->fetchAll();

function isLowStock($quantity, $threshold) {
    return $quantity <= $threshold;
}

function isExpired($expiration_date) {
    if (!$expiration_date) return false;
    return strtotime($expiration_date) < time();
}

$total_supplies = count($supplies);
$total_low_stock = count(array_filter($supplies, fn($s) => isLowStock($s['quantity'], $s['low_stock_threshold'])));
$total_expired = count(array_filter($supplies, fn($s) => isExpired($s['expiration_date'])));
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Dental Inventory Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
<style>
    /* RESET */
    *, *::before, *::after {
        box-sizing: border-box;
    }
    body, html {
        margin: 0; padding: 0; height: 100%;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #e6f0ff;
        color: #003366;
        scroll-behavior: smooth;
    }
    a {
        text-decoration: none;
        color: inherit;
    }
    button {
        cursor: pointer;
    }

    /* LAYOUT */
    body {
        display: flex;
        min-height: 100vh;
        overflow-x: hidden;
    }
    .sidebar {
        width: 250px;
        background: linear-gradient(180deg, #3399ff 0%, #0066cc 100%);
        color: #fff;
        display: flex;
        flex-direction: column;
        padding: 30px 20px;
        box-shadow: 3px 0 15px rgba(0,0,0,0.1);
    }
    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
        font-weight: 700;
        user-select: none;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }
    .sidebar a {
        padding: 15px 20px;
        margin-bottom: 12px;
        border-radius: 12px;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 12px;
        color: #cce0ff;
        transition: background-color 0.3s ease, color 0.3s ease;
        border-left: 5px solid transparent;
    }
    .sidebar a:hover,
    .sidebar a.active {
        background-color: rgba(255,255,255,0.2);
        color: #fff;
        border-left-color: #ffcc00;
        font-weight: 700;
    }
    .sidebar a i {
        min-width: 20px;
        font-size: 1.1rem;
    }

    main.main-content {
        flex: 1;
        background: #fff;
        padding: 40px 50px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 30px;
    }
    header h1 {
        font-size: 2.4rem;
        font-weight: 900;
        color: #004080;
        display: flex;
        align-items: center;
        gap: 15px;
        text-shadow: 1px 1px 4px #a3c2ff;
        margin: 0;
    }
    header h1 i {
        font-size: 2.8rem;
        color: #0066cc;
    }
 
    /* WIDGETS */
    .widgets {
        display: grid;
        grid-template-columns: repeat(auto-fit,minmax(220px,1fr));
        gap: 28px;
    }
    .widget {
        background: #f0f7ff;
        padding: 30px 25px;
        border-radius: 20px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.08);
        display: flex;
        flex-direction: column;
        gap: 8px;
        transition: background-color 0.3s ease, transform 0.3s ease;
        cursor: default;
        user-select: none;
    }
    .widget:hover {
        background-color: #d9e8ff;
        transform: translateY(-6px);
    }
    .widget i {
        font-size: 2.6rem;
        color: #3399ff;
    }
    .widget span {
        font-weight: 800;
        font-size: 1.8rem;
        color: #004080;
    }
    .widget small {
        font-weight: 600;
        color: #004080;
        opacity: 0.75;
    }

    /* TABLE */
    section table {
        width: 100%;
        border-collapse: collapse;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 10px 25px rgba(0,0,0,0.05);
        background-color: #f8fbff;
        font-size: 1rem;
        color: #003366;
    }
    table thead {
        background: #3399ff;
        color: #fff;
        font-weight: 700;
    }
    table thead tr th {
        padding: 15px 18px;
        text-align: left;
        user-select: none;
    }
    table tbody tr {
        border-bottom: 1px solid #d4e2ff;
        transition: background-color 0.25s ease;
    }
    table tbody tr:hover {
        background-color: #cde1ff;
    }
    table tbody tr.low-stock {
        background-color: #fff3cd;
    }
    table tbody tr.expired {
        background-color: #f8d7da;
    }
    table tbody tr.low-stock.expired {
        background-color: #f5c6cb;
    }
    table tbody tr td {
        padding: 12px 18px;
        vertical-align: middle;
    }
    table tbody tr td.actions {
        text-align: center;
        white-space: nowrap;
    }
    table tbody tr td.actions form {
        display: inline-block;
        margin: 0 5px;
    }
    table tbody tr td.actions button {
        border: none;
        background: none;
        font-size: 1.2rem;
        color: #3399ff;
        padding: 5px 8px;
        border-radius: 6px;
        transition: background-color 0.25s ease, color 0.25s ease;
    }
    table tbody tr td.actions button:hover {
        background-color: #3399ff;
        color: #fff;
    }
    table tbody tr td.actions button.delete:hover {
        background-color: #dc3545;
        color: #fff;
    }
    input[type=number] {
        width: 80px;
        padding: 6px 8px;
        border-radius: 8px;
        border: 1.5px solid #3399ff;
        font-weight: 600;
        text-align: center;
        font-size: 1rem;
        color: #003366;
        transition: border-color 0.25s ease;
    }
    input[type=number]:focus {
        outline: none;
        border-color: #0066cc;
        box-shadow: 0 0 7px rgba(51,153,255,0.5);
    }

    /* ADD FORM */
    form#add-supply {
        background: #f0f7ff;
        padding: 28px 30px;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        max-width: 600px;
        margin-top: 30px;
        user-select: none;
    }
    form#add-supply h2 {
        margin: 0 0 20px 0;
        color: #004080;
        font-weight: 900;
        font-size: 1.9rem;
        text-align: center;
        text-shadow: 1px 1px 3px #a3c2ff;
    }
    form#add-supply .form-row {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        margin-bottom: 18px;
    }
    form#add-supply label {
        flex: 1 0 120px;
        font-weight: 600;
        color: #003366;
        display: flex;
        align-items: center;
        gap: 6px;
        user-select: text;
    }
    form#add-supply input[type=text],
    form#add-supply input[type=number],
    form#add-supply input[type=date],
    form#add-supply textarea,
    form#add-supply select {
        flex: 2 1 250px;
        padding: 8px 12px;
        font-size: 1rem;
        border-radius: 12px;
        border: 1.5px solid #3399ff;
        transition: border-color 0.3s ease;
        color: #003366;
        font-weight: 600;
    }
    form#add-supply input[type=text]:focus,
    form#add-supply input[type=number]:focus,
    form#add-supply input[type=date]:focus,
    form#add-supply textarea:focus,
    form#add-supply select:focus {
        outline: none;
        border-color: #0066cc;
        box-shadow: 0 0 8px rgba(51,153,255,0.5);
    }
    form#add-supply textarea {
        min-height: 60px;
        resize: vertical;
    }
    form#add-supply button {
        display: block;
        margin: 0 auto;
        padding: 14px 40px;
        font-weight: 700;
        font-size: 1.2rem;
        border-radius: 20px;
        border: none;
        background: #3399ff;
        color: white;
        box-shadow: 0 6px 20px rgba(51,153,255,0.6);
        transition: background-color 0.3s ease;
        user-select: none;
    }
    form#add-supply button:hover {
        background: #0066cc;
        box-shadow: 0 10px 35px rgba(0,102,204,0.8);
    }

    /* FLASH MESSAGES */
    .flash-message {
        max-width: 600px;
        margin: 15px auto;
        padding: 16px 20px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 1.1rem;
        text-align: center;
        user-select: none;
        animation: fadeOut 6s forwards;
    }
    .flash-success {
        background-color: #d4edda;
        color: #155724;
        box-shadow: 0 10px 25px rgba(21, 87, 36, 0.15);
    }
    .flash-error {
        background-color: #f8d7da;
        color: #721c24;
        box-shadow: 0 10px 25px rgba(114, 28, 36, 0.15);
    }
    @keyframes fadeOut {
        0%, 80% {opacity: 1;}
        100% {opacity: 0; display: none;}
    }

    /* RESPONSIVE */
    @media (max-width: 900px) {
        body {
            flex-direction: column;
        }
        .sidebar {
            width: 100%;
            flex-direction: row;
            justify-content: center;
            padding: 10px 0;
            gap: 5px;
            overflow-x: auto;
            box-shadow: none;
        }
        .sidebar h2 {
            display: none;
        }
        .sidebar a {
            flex: 1 0 auto;
            padding: 10px 12px;
            margin-bottom: 0;
            border-radius: 0;
            border-left: none;
            font-size: 0.9rem;
            justify-content: center;
        }
        main.main-content {
            padding: 20px 15px;
        }
        table tbody tr td.actions {
            white-space: normal;
        }
        input[type=number] {
            width: 60px;
        }
        form#add-supply {
            max-width: 100%;
            padding: 20px;
        }
    }
</style>
</head>
<body>

    <nav class="sidebar">
        <h2><i class="fas fa-tooth"></i> DentiTrack</h2>
        <a href="dashboard.php" ><i class="fas fa-home"></i> Dashboard</a>
        <a href="add_patient.php"><i class="fas fa-user-plus"></i> Add Patient</a>
        <a href="view_patients.php"><i class="fas fa-users"></i> View Patients</a>
        <a href="view_appointments.php"><i class="fas fa-calendar-check"></i> Appointments</a>
        <a href="create_announcements.php"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="inventory.php"class="active"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>

<main class="main-content">
    <header>
        <h1><i class="fas fa-boxes-stacked"></i> Dental Supplies Inventory</h1>
    </header>

   

    <?php if ($message): ?>
        <div class="flash-message flash-success"><?=htmlspecialchars($message)?></div>
    <?php elseif ($error): ?>
        <div class="flash-message flash-error"><?=htmlspecialchars($error)?></div>
    <?php endif; ?>

    <div class="widgets">
        <div class="widget" title="Total Supplies">
            <i class="fas fa-cubes"></i>
            <span><?= $total_supplies ?></span>
            <small>Total Supplies</small>
        </div>
        <div class="widget" title="Low Stock Supplies">
            <i class="fas fa-exclamation-triangle"></i>
            <span><?= $total_low_stock ?></span>
            <small>Low Stock</small>
        </div>
        <div class="widget" title="Expired Supplies">
            <i class="fas fa-calendar-xmark"></i>
            <span><?= $total_expired ?></span>
            <small>Expired</small>
        </div>
    </div>

    <section>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Unit</th>
                    <th>Expiration Date</th>
                    <th>Low Stock Threshold</th>
                    <th class="actions">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($supplies as $supply): 
                    $lowStock = isLowStock($supply['quantity'], $supply['low_stock_threshold']);
                    $expired = isExpired($supply['expiration_date']);
                    $rowClass = ($lowStock ? 'low-stock ' : '') . ($expired ? 'expired' : '');
                ?>
                    <tr class="<?= $rowClass ?>">
                        <td><?= htmlspecialchars($supply['name']) ?></td>
                        <td><?= htmlspecialchars($supply['description']) ?></td>
                        <td><?= htmlspecialchars($supply['quantity']) ?></td>
                        <td><?= htmlspecialchars($supply['unit']) ?></td>
                        <td><?= $supply['expiration_date'] ? date('M d, Y', strtotime($supply['expiration_date'])) : 'N/A' ?></td>
                        <td><?= htmlspecialchars($supply['low_stock_threshold']) ?></td>
                        <td class="actions">
                            <!-- Update form -->
                            <form method="post" action="inventory.php" style="display:inline-block;">
                                <input type="hidden" name="action" value="update" />
                                <input type="hidden" name="supply_id" value="<?= $supply['supply_id'] ?>" />
                                <input type="number" name="quantity" value="<?= htmlspecialchars($supply['quantity']) ?>" min="0" required title="Quantity" />
                                <input type="number" name="low_stock_threshold" value="<?= htmlspecialchars($supply['low_stock_threshold']) ?>" min="0" required title="Low Stock Threshold" />
                                <button type="submit" title="Update"><i class="fas fa-pen"></i></button>
                            </form>

                            <!-- Delete form -->
                            <form method="post" action="inventory.php" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to delete this supply?');">
                                <input type="hidden" name="action" value="delete" />
                                <input type="hidden" name="supply_id" value="<?= $supply['supply_id'] ?>" />
                                <button type="submit" class="delete" title="Delete"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <?php if (empty($supplies)): ?>
                <tr><td colspan="7" style="text-align:center; color:#999;">No supplies found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>

    <form id="add-supply" method="post" action="inventory.php" novalidate>
        <h2>Add New Supply</h2>
        <input type="hidden" name="action" value="add" />
        <div class="form-row">
            <label for="name">Name <sup style="color:red;">*</sup></label>
            <input type="text" id="name" name="name" required placeholder="Supply name" autocomplete="off" />
        </div>
        <div class="form-row">
            <label for="description">Description</label>
            <textarea id="description" name="description" placeholder="Optional description..."></textarea>
        </div>
        <div class="form-row">
            <label for="quantity">Quantity <sup style="color:red;">*</sup></label>
            <input type="number" id="quantity" name="quantity" min="0" value="0" required />
        </div>
        <div class="form-row">
            <label for="unit">Unit</label>
            <select id="unit" name="unit" required>
                <option value="pcs" selected>pcs</option>
                <option value="boxes">boxes</option>
                <option value="packs">packs</option>
                <option value="ml">ml</option>
                <option value="grams">grams</option>
            </select>
        </div>
        <div class="form-row">
            <label for="expiration_date">Expiration Date</label>
            <input type="date" id="expiration_date" name="expiration_date" />
        </div>
        <div class="form-row">
            <label for="low_stock_threshold">Low Stock Threshold</label>
            <input type="number" id="low_stock_threshold" name="low_stock_threshold" min="0" value="5" />
        </div>
        <button type="submit">Add Supply</button>
    </form>
</main>

</body>
</html>
