<?php
session_start();
require_once '../config/dbpdo.php'; // your PDO connection file

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Fetch user with role secretary
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND role = 'secretary'");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    // Verify password
    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Invalid login credentials.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Secretary Login</title>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    crossorigin="anonymous"
    referrerpolicy="no-referrer"
  />
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f5f8ff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
    }
    .auth-wrapper {
      width: 400px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 12px 24px rgba(0,0,0,0.15);
      padding: 30px 40px;
      box-sizing: border-box;
    }
    .auth-container {
      display: flex;
      flex-direction: column;
    }
    h2 {
      color: #007bff;
      margin-bottom: 25px;
      text-align: center;
    }
    .input-icon {
      position: relative;
      margin-bottom: 20px;
    }
    .input-icon input {
      padding-left: 40px;
      width: 100%;
      height: 38px;
      font-size: 16px;
      border: 1.5px solid #ccc;
      border-radius: 7px;
      transition: border-color 0.3s;
      box-sizing: border-box;
    }
    .input-icon input:focus {
      outline: none;
      border-color: #007bff;
    }
    .input-icon i {
      position: absolute;
      top: 50%;
      left: 12px;
      transform: translateY(-50%);
      color: #007bff;
      font-size: 18px;
      pointer-events: none;
    }
    button {
      background-color: #007bff;
      color: white;
      font-weight: 600;
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 7px;
      font-size: 17px;
      cursor: pointer;
      transition: background-color 0.3s;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    button i {
      margin-right: 8px;
      font-size: 18px;
    }
    button:hover {
      background-color: #0056b3;
    }
    .error, .success {
      font-weight: 600;
      padding: 10px;
      border-radius: 7px;
      margin-bottom: 15px;
      text-align: center;
    }
    .error {
      background-color: #ffdddd;
      color: #cc0000;
    }
    .success {
      background-color: #ddffdd;
      color: #008800;
    }
    .back-button {
      margin-top: 20px;
      background-color: #eee;
      color: #444;
      border-radius: 7px;
      border: 1px solid #ccc;
      cursor: pointer;
      width: 100%;
      padding: 10px;
      font-size: 15px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .back-button i {
      margin-right: 8px;
    }
    .back-button:hover {
      background-color: #ddd;
    }
  </style>
</head>
<body>

<div class="auth-wrapper">
  <div class="auth-container">
    <div class="form-card" id="login-form">
      <h2><i class="fas fa-user-tie"></i> Secretary Login</h2>
      <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
      <?php endif; ?>
      <form method="POST" autocomplete="off">
        <div class="input-icon">
          <i class="fas fa-user"></i>
          <input type="text" name="username" placeholder="Username" required />
        </div>
        <div class="input-icon">
          <i class="fas fa-lock"></i>
          <input type="password" name="password" placeholder="Password" required />
        </div>
        <button type="submit" name="login"><i class="fas fa-right-to-bracket"></i> Login</button>
      </form>
    </div>
  </div>


</body>
</html>
