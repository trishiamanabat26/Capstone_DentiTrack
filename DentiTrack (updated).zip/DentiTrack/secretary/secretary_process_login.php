<?php
// secretary_process_login.php

session_start();
require_once '../config/db_pdo.php'; // Make sure this defines $pdo as PDO instance

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    if ($role !== 'secretary') {
        echo "Invalid role.";
        exit();
    }

    // Prepare statement to fetch secretary user by username and role
    $sql = "SELECT u.user_id, u.username, u.password_hash, s.full_name, s.contact_number, s.email 
            FROM users u 
            JOIN secretaries s ON u.user_id = s.user_id 
            WHERE u.username = ? AND u.role = ?";

    $stmt = $pdo->prepare($sql);
    if (!$stmt) {
        die("Prepare failed.");
    }

    $stmt->execute([$username, $role]);
    $user = $stmt->fetch();

    if ($user) {
        // Verify password
        if (password_verify($password, $user['password_hash'])) {
            // Password matches, set session variables
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['contact_number'] = $user['contact_number'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $role;

            // Redirect to secretary dashboard (change as needed)
            header("Location: secretary_dashboard.php");
            exit();
        } else {
            echo "Incorrect password.";
        }
    } else {
        echo "User not found.";
    }
} else {
    echo "Invalid request method.";
}
