<?php
// secretary_process_register.php

session_start();
require_once '../config/db.php'; // Assumes $pdo is PDO instance

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize form inputs
    $fullname = trim($_POST['fullname'] ?? '');
    $contact = trim($_POST['contact'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $role = 'secretary'; // Fixed role for secretary

    // Basic validation
    if ($password !== $confirm_password) {
        echo "Passwords do not match.";
        exit();
    }

    // Check if username or email already exists
    $sql_check = "SELECT user_id FROM users WHERE username = :username OR email = :email";
    $stmt_check = $pdo->prepare($sql_check);
    $stmt_check->execute(['username' => $username, 'email' => $email]);
    
    if ($stmt_check->rowCount() > 0) {
        echo "Username or email already exists.";
        exit();
    }

    // Hash the password securely
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    try {
        // Use transaction since inserting into two tables (users and secretaries)
        $pdo->beginTransaction();

        // Insert into users table
        $sql_insert_user = "INSERT INTO users (username, password_hash, role, email) VALUES (:username, :password_hash, :role, :email)";
        $stmt_user = $pdo->prepare($sql_insert_user);
        $stmt_user->execute([
            'username' => $username,
            'password_hash' => $password_hash,
            'role' => $role,
            'email' => $email,
        ]);

        // Get last inserted user_id
        $user_id = $pdo->lastInsertId();

        // Insert into secretaries table
        $sql_insert_secretary = "INSERT INTO secretaries (user_id, full_name, contact_number) VALUES (:user_id, :full_name, :contact_number)";
        $stmt_sec = $pdo->prepare($sql_insert_secretary);
        $stmt_sec->execute([
            'user_id' => $user_id,
            'full_name' => $fullname,
            'contact_number' => $contact,
        ]);

        $pdo->commit();

        // Registration success - redirect to login page
        header("Location: secretary_login.php?register=success");
        exit();

    } catch (Exception $e) {
        $pdo->rollBack();
        echo "Failed to register secretary: " . $e->getMessage();
        exit();
    }

} else {
    echo "Invalid request method.";
}
