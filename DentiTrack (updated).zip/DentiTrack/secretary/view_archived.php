<?php
session_start();

// Restrict access to secretaries only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: secretary_login.php');
    exit();
}

include '../config/db_pdo.php';

$search = trim($_GET['search'] ?? '');

try {
    // Prepare SQL with named placeholders for search on multiple fields including address
    $sql = "SELECT archive_id, patient_id, full_name, dob, archived_at, contact_info, address 
            FROM patient_archive 
            WHERE full_name LIKE :search 
               OR contact_info LIKE :search
               OR address LIKE :search
            ORDER BY patient_id DESC";
    $stmt = $conn->prepare($sql);
    $search_term = '%' . $search . '%';
    $stmt->bindValue(':search', $search_term, PDO::PARAM_STR);
    $stmt->execute();
    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database query error in view_archived.php: " . $e->getMessage());
    $patients = [];
}

function calculateAge($dob) {
    if (!$dob) return '';
    try {
        $dobDate = new DateTime($dob);
        $now = new DateTime();
        return $now->diff($dobDate)->y;
    } catch (Exception $e) {
        return '';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Archived Patients - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" />
<style>
    html { scroll-behavior: smooth; }
    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background: #e6f0ff;
        color: #003366;
        height: 100vh;
        display: flex;
    }
    .sidebar {
        width: 220px;
        background: linear-gradient(to bottom, #3399ff, #0066cc);
        padding: 20px;
        color: white;
        box-shadow: 2px 0 10px rgba(0,0,0,0.15);
        display: flex;
        flex-direction: column;
    }
    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
        font-weight: 700;
        user-select: none;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
    }
    .sidebar a {
        display: block;
        padding: 12px 20px;
        margin: 10px 0;
        color: #cce0ff;
        text-decoration: none;
        border-left: 4px solid transparent;
        font-weight: 600;
        transition: background-color 0.3s ease, border-left-color 0.3s ease;
    }
    .sidebar a:hover,
    .sidebar a.active {
        background-color: rgba(255,255,255,0.15);
        color: white;
        border-left: 4px solid #ffcc00;
    }
    main.main-content {
        flex: 1;
        padding: 40px;
        background: white;
        overflow-y: auto;
    }
    header {
        margin-bottom: 30px;
    }
    header h1 {
        font-size: 2rem;
        color: #004080;
        text-shadow: 1px 1px 2px #a3c2ff;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .search-box {
        margin-bottom: 20px;
    }
    .search-box input[type="text"] {
        width: 320px;
        padding: 12px 15px;
        border-radius: 12px;
        border: 1.5px solid #b3c6ff;
        font-size: 16px;
        outline-offset: 2px;
        transition: border-color 0.3s ease;
    }
    .search-box input[type="text"]:focus {
        border-color: #3399ff;
        outline: none;
        box-shadow: 0 0 8px #3399ff88;
    }
    .search-box button {
        background-color: #0066cc;
        color: white;
        font-weight: 700;
        font-size: 16px;
        padding: 12px 22px;
        border: none;
        border-radius: 12px;
        cursor: pointer;
        margin-left: 8px;
        box-shadow: 0 4px 10px rgba(0,102,204,0.4);
        transition: background-color 0.3s ease;
    }
    .search-box button:hover {
        background-color: #004080;
        box-shadow: 0 6px 12px rgba(0,64,128,0.6);
    }
    table {
        width: 100%;
        border-collapse: collapse;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 6px 16px rgba(0,0,0,0.1);
        background: #f9fbff;
    }
    th, td {
        padding: 14px 18px;
        text-align: left;
        border-bottom: 1px solid #e2e8f0;
        font-weight: 600;
        vertical-align: middle;
    }
    th {
        background: linear-gradient(to right, #3399ff, #0066cc);
        color: white;
        user-select: none;
        letter-spacing: 0.05em;
    }
    tr:hover {
        background-color: #d0e1ff;
    }
    .no-results {
        font-size: 1.2rem;
        color: #666;
        padding: 20px;
        text-align: center;
    }
    a.action-btn, button.action-btn {
        color: #0066cc;
        font-weight: 700;
        text-decoration: none;
        padding: 6px 14px;
        border: 1.5px solid #0066cc;
        border-radius: 12px;
        transition: background-color 0.3s ease, color 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
        background: none;
        cursor: pointer;
        font-family: inherit;
        font-size: 1rem;
    }
    a.action-btn:hover, button.action-btn:hover {
        background-color: #0066cc;
        color: white;
    }
    button.action-btn {
        border: 1.5px solid #009933;
        color: #009933;
    }
    button.action-btn:hover {
        background-color: #009933;
        color: white;
    }
    .message-success {
        color: #007a00;
        font-weight: 700;
        margin-bottom: 1rem;
    }
    .message-error {
        color: #cc0000;
        font-weight: 700;
        margin-bottom: 1rem;
    }
</style>
</head>
<body>

<nav class="sidebar" role="navigation" aria-label="Primary Navigation">
    <h2><i class="fas fa-tooth" aria-hidden="true"></i> DentiTrack</h2>
    <a href="dashboard.php"><i class="fas fa-home" aria-hidden="true"></i> Dashboard</a>
    <a href="add_patient.php"><i class="fas fa-user-plus" aria-hidden="true"></i> Add Patient</a>
    <a href="view_patients.php"><i class="fas fa-users" aria-hidden="true"></i> View Patients</a>
    <a href="appointments.php"><i class="fas fa-calendar-check" aria-hidden="true"></i> Appointments</a>
    <a href="create_announcements.php"><i class="fas fa-bullhorn" aria-hidden="true"></i> Announcements</a>
    <a href="view_archived.php" class="active"><i class="fas fa-archive" aria-hidden="true"></i> Archived Patients</a>
    <a href="inventory.php"><i class="fas fa-boxes" aria-hidden="true"></i> Inventory</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt" aria-hidden="true"></i> Logout</a>
</nav>

<main class="main-content" role="main" tabindex="-1">
    <header>
        <h1><i class="fas fa-archive" aria-hidden="true"></i> Archived Patients</h1>
    </header>

    <?php if (isset($_SESSION['message'])): ?>
        <div role="alert" aria-live="assertive" class="message-success">
            <?= htmlspecialchars($_SESSION['message']) ?>
        </div>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div role="alert" aria-live="assertive" class="message-error">
            <?= htmlspecialchars($_SESSION['error']) ?>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <form method="GET" class="search-box" action="view_archived.php" role="search" aria-label="Search Archived Patients">
        <input
            type="text"
            name="search"
            placeholder="Search archived by name, contact, or address"
            value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>"
            aria-describedby="search-desc"
            autocomplete="off"
            autofocus
        />
        <button type="submit" aria-label="Search"><i class="fas fa-search" aria-hidden="true"></i> Search</button>
    </form>

    <?php if (empty($patients)): ?>
        <p class="no-results" role="status" aria-live="polite">No archived patients found.</p>
    <?php else: ?>
    <table role="table" aria-label="Archived Patients List" summary="List of archived patients with options to recover">
        <thead>
            <tr>
                <th scope="col">Archive ID</th>
                <th scope="col">Patient ID</th>
                <th scope="col">Name</th>
                <th scope="col">Age</th>
                <th scope="col">Contact</th>
                <th scope="col">Archived Date</th>
                <th scope="col" style="text-align:center;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($patients as $patient): ?>
            <tr>
                <td><?= htmlspecialchars($patient['archive_id']) ?></td>
                <td><?= htmlspecialchars($patient['patient_id']) ?></td>
                <td><?= htmlspecialchars($patient['full_name']) ?></td>
                <td><?= calculateAge($patient['dob']) ?></td>
                <td><?= htmlspecialchars($patient['contact_info']) ?></td>
                <td><?= htmlspecialchars(date('F j, Y', strtotime($patient['archived_at']))) ?></td>
                <td style="text-align:center;">
                    <form method="POST" action="recover_patient.php" onsubmit="return confirm('Are you sure you want to recover this patient?');" style="display:inline;">
                        <input type="hidden" name="id" value="<?= htmlspecialchars($patient['patient_id']) ?>">
                        <button type="submit" class="action-btn" aria-label="Recover patient <?= htmlspecialchars($patient['full_name']) ?>">
                            <i class="fas fa-undo" aria-hidden="true"></i> Recover
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</main>

</body>
</html>
