<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'secretary') {
    header('Location: secretary_login.php');
    exit();
}

include '../config/db_pdo.php'; // $conn PDO instance

$search = trim($_GET['search'] ?? '');

$sql = "SELECT * FROM patient WHERE full_name LIKE :search1 OR contact_info LIKE :search2 ORDER BY patient_id DESC";
$stmt = $conn->prepare($sql);
$search_term = "%$search%";
$stmt->bindParam(':search1', $search_term, PDO::PARAM_STR);
$stmt->bindParam(':search2', $search_term, PDO::PARAM_STR);
$stmt->execute();
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

function calculateAge($dob) {
    if (!$dob) return '';
    try {
        $dobDate = new DateTime($dob);
        $now = new DateTime();
        return $now->diff($dobDate)->y;
    } catch (Exception $e) {
        return '';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>View Patients - DentiTrack</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous" />
<style>
html { scroll-behavior: smooth; }
body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: #e6f0ff;
    color: #003366;
    height: 100vh;
    display: flex;
}
.sidebar {
    width: 220px;
    background: linear-gradient(to bottom, #3399ff, #0066cc);
    padding: 20px;
    color: white;
    box-shadow: 2px 0 10px rgba(0,0,0,0.15);
    display: flex;
    flex-direction: column;
}
.sidebar h2 {
    text-align: center;
    margin-bottom: 30px;
    font-size: 24px;
    font-weight: 700;
    user-select: none;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
}
.sidebar a {
    display: block;
    padding: 12px 20px;
    margin: 10px 0;
    color: #cce0ff;
    text-decoration: none;
    border-left: 4px solid transparent;
    font-weight: 600;
    transition: background-color 0.3s ease, border-left-color 0.3s ease;
}
.sidebar a:hover,
.sidebar a.active {
    background-color: rgba(255,255,255,0.15);
    color: white;
    border-left: 4px solid #ffcc00;
}
main.main-content {
    flex: 1;
    padding: 40px;
    background: white;
    overflow-y: auto;
}
header {
    margin-bottom: 30px;
}
header h1 {
    font-size: 2rem;
    color: #004080;
    text-shadow: 1px 1px 2px #a3c2ff;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
.search-box {
    margin-bottom: 20px;
}
.search-box input[type="text"] {
    width: 320px;
    padding: 12px 15px;
    border-radius: 12px;
    border: 1.5px solid #b3c6ff;
    font-size: 16px;
    outline-offset: 2px;
    transition: border-color 0.3s ease;
}
.search-box input[type="text"]:focus {
    border-color: #3399ff;
    outline: none;
    box-shadow: 0 0 8px #3399ff88;
}
.search-box button {
    background-color: #0066cc;
    color: white;
    font-weight: 700;
    font-size: 16px;
    padding: 12px 22px;
    border: none;
    border-radius: 12px;
    cursor: pointer;
    margin-left: 8px;
    box-shadow: 0 4px 10px rgba(0,102,204,0.4);
    transition: background-color 0.3s ease;
}
.search-box button:hover {
    background-color: #004080;
    box-shadow: 0 6px 12px rgba(0,64,128,0.6);
}
table {
    width: 100%;
    border-collapse: collapse;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 6px 16px rgba(0,0,0,0.1);
    background: #f9fbff;
}
th, td {
    padding: 14px 18px;
    text-align: left;
    border-bottom: 1px solid #e2e8f0;
    font-weight: 600;
}
th {
    background: linear-gradient(to right, #3399ff, #0066cc);
    color: white;
    user-select: none;
    letter-spacing: 0.05em;
}
tr:hover {
    background-color: #d0e1ff;
}
.no-results {
    font-size: 1.2rem;
    color: #666;
    padding: 20px;
    text-align: center;
}
a.action-btn {
    color: #0066cc;
    font-weight: 700;
    text-decoration: none;
    padding: 6px 14px;
    border: 1.5px solid #0066cc;
    border-radius: 12px;
    transition: background-color 0.3s ease, color 0.3s ease;
}
a.action-btn:hover {
    background-color: #0066cc;
    color: white;
}
a.archive-btn {
    border-color: #cc6600;
    color: #cc6600;
}
a.archive-btn:hover {
    background-color: #cc6600;
    color: white;
}
</style>
</head>
<body>

<nav class="sidebar" role="navigation" aria-label="Main sidebar navigation">
    <h2><i class="fas fa-tooth" aria-hidden="true"></i> DentiTrack</h2>
    <a href="dashboard.php"><i class="fas fa-home" aria-hidden="true"></i> Dashboard</a>
    <a href="add_patient.php"><i class="fas fa-user-plus" aria-hidden="true"></i> Add Patient</a>
    <a href="view_patients.php" class="active" aria-current="page"><i class="fas fa-users" aria-hidden="true"></i> View Patients</a>
    <a href="appointments.php"><i class="fas fa-calendar-check" aria-hidden="true"></i> Appointments</a>
    <a href="create_announcements.php"><i class="fas fa-bullhorn" aria-hidden="true"></i> Announcements</a>
    <a href="view_archived.php"><i class="fas fa-archive" aria-hidden="true"></i> Archived Patients</a>
    <a href="inventory.php"><i class="fas fa-boxes" aria-hidden="true"></i> Inventory</a>
    <a href="logout.php"><i class="fas fa-sign-out-alt" aria-hidden="true"></i> Logout</a>
</nav>

<main class="main-content">
    <header>
        <h1><i class="fas fa-users" aria-hidden="true"></i> Patients List</h1>
    </header>

    <form method="GET" class="search-box" action="view_patients.php" role="search" aria-label="Search Patients">
        <input
            type="text"
            name="search"
            placeholder="Search by name or contact"
            value="<?= htmlspecialchars($search) ?>"
            aria-describedby="search-desc"
            aria-label="Search patients by name or contact"
        />
        <button type="submit" aria-label="Search patients"><i class="fas fa-search" aria-hidden="true"></i> Search</button>
    </form>
    
    <?php if (count($patients) === 0): ?>
        <p class="no-results" role="alert">No patients found.</p>
    <?php else: ?>
    <table role="table" aria-label="Patients List">
        <thead>
            <tr>
                <th scope="col">#ID</th>
                <th scope="col">Name</th>
                <th scope="col">Age</th>
                <th scope="col">Contact</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($patients as $patient): ?>
            <tr>
                <td><?= (int)$patient['patient_id'] ?></td>
                <td><?= htmlspecialchars($patient['full_name']) ?></td>
                <td><?= htmlspecialchars(calculateAge($patient['dob'])) ?></td>
                <td><?= htmlspecialchars($patient['contact_info']) ?></td>
                <td>
                           <a href="edit_patient_account.php?id=<?= (int)$patient['patient_id'] ?>" class="action-btn" aria-label="Edit patient <?= htmlspecialchars($patient['full_name'], ENT_QUOTES) ?>">
    <i class="fas fa-edit" aria-hidden="true"></i> Edit
</a>
                    &nbsp;
                    <a href="archive_patients.php?id=<?= (int)$patient['patient_id'] ?>" 
                       class="action-btn archive-btn"
                       onclick="return confirm('Are you sure you want to archive this patient?');"
                       aria-label="Archive patient <?= htmlspecialchars($patient['full_name'], ENT_QUOTES) ?>">
                       <i class="fas fa-archive" aria-hidden="true"></i> Archive
                    </a>
                    &nbsp;


                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</main>

</body>
</html>
