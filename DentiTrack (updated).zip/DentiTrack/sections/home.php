<div class="home-container">
    <div class="home-text">
        <h1>Welcome to DentiTrack</h1>
        <p>Management Solution for Patient Records and Inventory</p>
    </div>
</div>
